'''
ANGLES OF A TRIANGLE - VALID OR NOT
'''


res = 'Y'

while res == 'y' or res == 'Y':
    print('Enter angles of a triangle .... ')
    angleA = float(input('Angle A : '))
    angleB = float(input('Angle B : '))
    angleC = float(input('Angle C : '))

    if (angleA + angleB + angleC == float(180)):
        print('The triangle with angles {} ,{} & {} is a valid one .'.format(angleA, angleB, angleC))
    else:
        print('The triangle with angles {} ,{} & {} is an invalid one .'.format(angleA, angleB, angleC))

    res = input('Do you want to continue ? (Y/N): ')
