'''
PYTHAGOREAN INPUT OR NOT
'''

print('Enter 3 sides of a triangle ...')
a = float(input('a = '))
b = float(input('b = '))
c = float(input('c = '))


if a*a == b*b + c*c:
    print('{} ,{} and {} make a pythagorean triplet with {} being the hypotenuse.'.format(a,b,c,a))
elif b*b==a*a + c*c:
    print('{}, {} and {} make a pythagorean triplet with {} being the hypotenuse.'.format(a, b, c, b))
elif c*c == a*a + b*b:
    print('{} ,{} and {} make a pythagorean triplet with {} being the hypotenuse.'.format(a, b, c, c))
else :
    print('{} ,{} and {} do not make a pythagorean triplet. '.format(a,b,c))
