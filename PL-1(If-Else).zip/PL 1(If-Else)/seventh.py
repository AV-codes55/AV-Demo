'''
ALPHABET , DIGIT OR A SPEACIAL CHARACTER
'''


res = 'y'

while res == 'Y' or res == 'y':
    ch = input('Enter a character : ')

    if (ch >= 'A' and ch <= 'Z') or (ch >= 'a' and ch <= 'z'):
        print('{} is an alphabet .'.format(ch))
    elif (ch >= chr(48) and ch <= chr(57)):
        print('{} is a digit.'.format(ch))
    else:
        print('{} is a special character .'.format(ch))


    res = input ('Do you want to continue ? (Y/N): ')