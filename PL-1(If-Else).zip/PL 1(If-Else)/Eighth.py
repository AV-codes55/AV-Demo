'''
UPPERCASE OR LOWERCASE
'''


res = 'y'

while res == 'Y' or res =='y':
    ch = input('Enter an alphabet : ')

    if (ch >= 'A' and ch <= 'Z'):
        print(ch, ' is in UPPERCASE.')
    elif (ch >= 'a' and ch <= 'z'):
        print(ch, ' is in lowercase.')
    else:
        print('Invalid Input.')

    res = input ('Do you want to continue ? (Y/N): ')
    