'''
MAX AMONG 3 NUMBERS
'''


print('HEY, MAXXXX.....')
n1 = int (input ('Enter first number: '))
n2 = int (input ('Enter second number: '))
n3 = int (input ('Enter third number: '))



if n1 > n2 :
    if n1 > n3:
        print(n1,'is the maximum of all.')
    else :
        print(n3 , 'is the maximum of all.')
else :
    if n2>n3:
        print(n2, ' is the maximum of all.')
    else :
        print(n3, ' is the maximum of all.')
