'''
alphabet lies between I to S
'''

res = 'y'

while res == 'Y' or res == 'y':
    ch = input('Enter an alphabet : ')

    if (ch >= 'I' and ch <= 'S') or (ch >= 'i' and ch <= 's'):
        print('Yes')
    else:
        print('No')
    res = input ('Do you want to continue ? (y/N): ')